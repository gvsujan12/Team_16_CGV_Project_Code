using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;

public class FailCondition : MonoBehaviour
{
    public GameObject[] fruitPrefabs;
    private int largestFruitIndex =3;  // To store the index of the largest fruit encountered

    private void CaptureScreenshot()
    {
        StartCoroutine(TakeScreenShot((result) =>
        {
            // Assign the texture to the "GameScreenshot" UI Image object
            GameObject gameScreenshot = GameObject.Find("GameScreenshot");

            if (gameScreenshot != null)
            {
                if (gameScreenshot.TryGetComponent<Image>(out var gameScreenshotImage))
                {
                    gameScreenshotImage.sprite = Sprite.Create(result, new Rect(0, 0, result.width, result.height), new Vector2(0, 0));
                }
            }
        }));
    }

    public void Failure()
    {
        SaveScore();
        CaptureScreenshot();

        // Stop the spawner
        GameObject spawner = GameObject.Find("Spawner");
        if (spawner != null)
        {
            if (spawner.TryGetComponent<FruitSpawner>(out var fruitSpawner))
            {
                fruitSpawner.isRunning = false;
            }
        }

        // Slide the "LosingScreen" object into view
        GameObject losingScreen = GameObject.Find("LosingScreen");
        GameObject bg = GameObject.Find("Background");
        if (losingScreen != null && bg != null)
        {
            Animator bgAnimator = bg.GetComponent<Animator>();
            Animator losingScreenAnimator = losingScreen.GetComponent<Animator>();
            if (losingScreenAnimator != null && bgAnimator != null)
            {
                losingScreenAnimator.SetBool("Lost", true);
                bgAnimator.SetBool("Lost", true);
            }
        }

        // Count every fruit in the scene and destroy them while adding to the score with the formula (index + 1) * 2
        GameObject[] fruits = GameObject.FindGameObjectsWithTag("Fruit");
        // Freeze the game and destroy fruits
        foreach (GameObject fruit in fruits)
        {
            StartCoroutine(DeleteFruitWithDelay(fruit));
        }

        // Optionally, you can display the largest fruit index here, if needed
        Debug.Log("Largest Fruit Index: " + largestFruitIndex);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "Fruit")
        {
            // Check if the collided fruit is larger than the current largest
            TrackLargestFruit(collision.gameObject);
            Failure();
        }
    }

    private void TrackLargestFruit(GameObject fruit)
    {
        // Find the index of the fruit in the fruitPrefabs array
        for (int i = 0; i < fruitPrefabs.Length; i++)
        {
            if (fruit == fruitPrefabs[i])
            {
                // Since fruitPrefabs is in increasing size order, we can directly compare
                // the index to track the largest fruit
                if (i > largestFruitIndex)
                {
                    largestFruitIndex = i; // Update the largest fruit index
                }
                break;
            }
        }
    }

    IEnumerator TakeScreenShot(System.Action<Texture2D> callback)
    {
        yield return new WaitForEndOfFrame();
        Texture2D texture = ScreenCapture.CaptureScreenshotAsTexture();
        callback(texture);
    }

    IEnumerator DeleteFruitWithDelay(GameObject fruit)
    {
        yield return new WaitForSeconds(0.1f);
        Destroy(fruit);
    }

    void SaveScore()
    {
        GameObject score = GameObject.Find("score");
        // Use GetComponentInParent to find the Highscore component, considering hierarchy
        Highscore highscoreComponent = score.GetComponentInParent<Highscore>();
        if (highscoreComponent != null)
        {
            highscoreComponent.SaveScore();
        }
    }

	public int GetLargestFruitIndex() { return largestFruitIndex; }

}
