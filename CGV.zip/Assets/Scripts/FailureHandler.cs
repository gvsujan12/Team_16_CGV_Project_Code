using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using TMPro;



public class FailureHandler : MonoBehaviour
{
    public TextMeshProUGUI predictionText;  // UI Text element named "Prediction" to display the predicted rank
    private int largestFruitIndex = 4;  // Example index (replace with actual logic)
    private int numMerges = 10;        // Example value (replace with actual logic)
    private int numClicks = 20;        // Example value (replace with actual logic)
    private int score = 300;           // Example score (replace with actual logic)

    // Flask server URL
    private string flaskUrl = "http://127.0.0.1:5000/predict";  // Update with your server's IP if needed

    // Update is called once per frame
    void Update()
    {
        // Detect when the ESC key is pressed and trigger the game failure logic
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            OnGameFailure();
        }
    }

    public void OnGameFailure()
    {
        // Send data to Flask API and display the result on failure
        StartCoroutine(SendFailureData());
    }

    private IEnumerator SendFailureData()
    {
        // Create the JSON payload manually to match the Flask server format
        string jsonData = $"{{\"largest_fruit\": {largestFruitIndex}, \"num_merges\": {numMerges}, \"num_clicks\": {numClicks}, \"score\": {score}}}";

        Debug.Log("Sending JSON data: " + jsonData); // Print the JSON data

        // Create a POST request
        using (UnityWebRequest www = new UnityWebRequest(flaskUrl, UnityWebRequest.kHttpVerbPOST))
        {
            // Set the request headers
            www.SetRequestHeader("Content-Type", "application/json");

            // Set the request body
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
            www.uploadHandler = new UploadHandlerRaw(bodyRaw);
            www.downloadHandler = new DownloadHandlerBuffer();

            // Send the request and wait for the response
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                // Parse the response JSON
                string jsonResponse = www.downloadHandler.text;
                Debug.Log("Prediction Response: " + jsonResponse);

                // Extract the predicted rank from the response
                string predictedRank = ParsePredictionResponse(jsonResponse);

                // Display the result in the "Prediction" text box
                predictionText.text = "Predicted Rank: " + predictedRank;
            }
            else
            {
                Debug.LogError("Request failed: " + www.error);
                predictionText.text = "Request failed: " + www.error;
            }
        }
    }

    // Parse the prediction response to extract the predicted rank
    private string ParsePredictionResponse(string response)
    {
        // Simple JSON parsing assuming the response is like:
        // {"predicted_rank": "Advanced"}
        var json = JsonUtility.FromJson<PredictionResponse>(response);
        return json.predicted_rank;
    }

    // Define a class to match the structure of the JSON response
    [System.Serializable]
    public class PredictionResponse
    {
        public string predicted_rank;
    }
}
