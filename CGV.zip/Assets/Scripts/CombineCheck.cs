using System.Collections;
using TMPro;
using UnityEngine;

public class CombineCheck : MonoBehaviour
{
    public GameObject[] fruitPrefabs;
    private Coroutine mergingCoroutine;
    private static int mergeCount = 0; // Static variable to count merges

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == transform.gameObject.name)
        {
            // Update the score
            GameObject scoreText = GameObject.Find("score");
            if (scoreText != null)
            {
                TextMeshProUGUI scoreTextMesh = scoreText.GetComponent<TextMeshProUGUI>();
                if (scoreTextMesh != null)
                {
                    int fruitIndex = System.Array.FindIndex(this.fruitPrefabs, fruit => fruit.name == transform.gameObject.name);
                    string newScore = (int.Parse(scoreTextMesh.text) + (int)Mathf.Floor(fruitIndex * 2.25f + 1f)).ToString();
                    scoreTextMesh.text = newScore;
                    GameObject.Find("FinalScore").GetComponent<TextMeshProUGUI>().text = newScore;
                }
            }

            // Increment merge count
            mergeCount++;

            // Determine the master fruit based on their unique identifiers
            CombineCheck masterFruit = DetermineMasterFruit(collision.gameObject.GetComponent<CombineCheck>());
            if (masterFruit == this)
            {
                if (mergingCoroutine != null)
                {
                    StopCoroutine(mergingCoroutine);
                }
                mergingCoroutine = StartCoroutine(HandleCollision(collision));
            }
        }
    }

    private CombineCheck DetermineMasterFruit(CombineCheck otherCombineCheck)
    {
        return (GetInstanceID() > otherCombineCheck.GetInstanceID()) ? this : otherCombineCheck;
    }

    private IEnumerator HandleCollision(Collision2D collision)
    {
        int fruitIndex = System.Array.FindIndex(this.fruitPrefabs, fruit => fruit.name == transform.gameObject.name);

        if (fruitIndex < this.fruitPrefabs.Length - 1)
        {
            Destroy(collision.gameObject);
            GameObject newFruit = Instantiate(this.fruitPrefabs[fruitIndex + 1], transform.position, Quaternion.identity);
            newFruit.name = this.fruitPrefabs[fruitIndex + 1].name;

            newFruit.GetComponent<Rigidbody2D>().isKinematic = false;

            yield return new WaitForSeconds(0.1f);
            Destroy(gameObject);

            GameObject spawner = GameObject.Find("Spawner");
            if (spawner != null)
            {
                AudioSource audioSource = spawner.GetComponent<AudioSource>();
                if (audioSource != null)
                {
                    audioSource.Play();
                }
            }
        }
    }

    private void OnDestroy()
    {
        if (mergingCoroutine != null)
        {
            StopCoroutine(mergingCoroutine);
        }
    }

    public int GetMergeCount() { return mergeCount; }
}
